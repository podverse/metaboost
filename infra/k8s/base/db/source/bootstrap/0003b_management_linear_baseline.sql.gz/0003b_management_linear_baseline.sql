-- GENERATED FILE (do not edit) — see scripts/database/generate-linear-baseline.sh

-- Management database baseline (schema + migration-materialized data; applied as DB_MANAGEMENT_MIGRATOR_USER).

-- linear_migration_history data is appended deterministically from migration filenames + checksums.

--
-- PostgreSQL database dump
--


-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: server_time_with_default; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.server_time_with_default AS timestamp with time zone DEFAULT now();


--
-- Name: varchar_password; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_password AS character varying(60);


--
-- Name: varchar_short; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_short AS character varying(50);


--
-- Name: varchar_token_hash; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_token_hash AS character varying(64);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_permissions (
    admin_id uuid NOT NULL,
    admins_crud integer DEFAULT 0 NOT NULL,
    users_crud integer DEFAULT 0 NOT NULL,
    buckets_crud integer DEFAULT 0 NOT NULL,
    bucket_messages_crud integer DEFAULT 0 NOT NULL,
    bucket_admins_crud integer DEFAULT 0 NOT NULL,
    billing_prices_crud integer DEFAULT 0 NOT NULL,
    event_visibility text DEFAULT 'all_admins'::text NOT NULL,
    CONSTRAINT admin_permissions_admins_crud_check CHECK (((admins_crud >= 0) AND (admins_crud <= 15))),
    CONSTRAINT admin_permissions_billing_prices_crud_check CHECK (((billing_prices_crud >= 0) AND (billing_prices_crud <= 15))),
    CONSTRAINT admin_permissions_bucket_admins_crud_check CHECK (((bucket_admins_crud >= 0) AND (bucket_admins_crud <= 15))),
    CONSTRAINT admin_permissions_bucket_messages_crud_check CHECK (((bucket_messages_crud >= 0) AND (bucket_messages_crud <= 15))),
    CONSTRAINT admin_permissions_buckets_crud_check CHECK (((buckets_crud >= 0) AND (buckets_crud <= 15))),
    CONSTRAINT admin_permissions_event_visibility_check CHECK ((event_visibility = ANY (ARRAY['own'::text, 'all_admins'::text, 'all'::text]))),
    CONSTRAINT admin_permissions_users_crud_check CHECK (((users_crud >= 0) AND (users_crud <= 15)))
);


--
-- Name: linear_migration_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.linear_migration_history (
    id integer NOT NULL,
    migration_filename character varying(255) NOT NULL,
    migration_checksum character varying(64) NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: linear_migration_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.linear_migration_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: linear_migration_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.linear_migration_history_id_seq OWNED BY public.linear_migration_history.id;


--
-- Name: management_admin_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.management_admin_role (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name public.varchar_short NOT NULL,
    admins_crud integer NOT NULL,
    users_crud integer NOT NULL,
    buckets_crud integer NOT NULL,
    bucket_messages_crud integer NOT NULL,
    bucket_admins_crud integer NOT NULL,
    billing_prices_crud integer DEFAULT 0 NOT NULL,
    event_visibility text NOT NULL,
    created_at public.server_time_with_default NOT NULL,
    CONSTRAINT management_admin_role_admins_crud_check CHECK (((admins_crud >= 0) AND (admins_crud <= 15))),
    CONSTRAINT management_admin_role_billing_prices_crud_check CHECK (((billing_prices_crud >= 0) AND (billing_prices_crud <= 15))),
    CONSTRAINT management_admin_role_bucket_admins_crud_check CHECK (((bucket_admins_crud >= 0) AND (bucket_admins_crud <= 15))),
    CONSTRAINT management_admin_role_bucket_messages_crud_check CHECK (((bucket_messages_crud >= 0) AND (bucket_messages_crud <= 15))),
    CONSTRAINT management_admin_role_buckets_crud_check CHECK (((buckets_crud >= 0) AND (buckets_crud <= 15))),
    CONSTRAINT management_admin_role_event_visibility_check CHECK ((event_visibility = ANY (ARRAY['own'::text, 'all_admins'::text, 'all'::text]))),
    CONSTRAINT management_admin_role_users_crud_check CHECK (((users_crud >= 0) AND (users_crud <= 15)))
);


--
-- Name: management_event; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.management_event (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor_id text NOT NULL,
    actor_type text NOT NULL,
    actor_display_name text,
    action text NOT NULL,
    target_type text,
    target_id text,
    "timestamp" public.server_time_with_default NOT NULL,
    details text,
    CONSTRAINT management_event_actor_type_check CHECK ((actor_type = ANY (ARRAY['super_admin'::text, 'admin'::text])))
);


--
-- Name: management_refresh_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.management_refresh_token (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    management_user_id uuid NOT NULL,
    token_hash public.varchar_token_hash NOT NULL,
    expires_at timestamp without time zone NOT NULL
);


--
-- Name: management_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.management_user (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    is_super_admin boolean DEFAULT false NOT NULL,
    created_at public.server_time_with_default NOT NULL,
    created_by uuid
);


--
-- Name: management_user_bio; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.management_user_bio (
    management_user_id uuid NOT NULL,
    display_name public.varchar_short NOT NULL
);


--
-- Name: management_user_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.management_user_credentials (
    management_user_id uuid NOT NULL,
    username public.varchar_short NOT NULL,
    password_hash public.varchar_password NOT NULL
);


--
-- Name: linear_migration_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.linear_migration_history ALTER COLUMN id SET DEFAULT nextval('public.linear_migration_history_id_seq'::regclass);


--
-- Data for Name: admin_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_permissions (admin_id, admins_crud, users_crud, buckets_crud, bucket_messages_crud, bucket_admins_crud, billing_prices_crud, event_visibility) FROM stdin;
\.


--
-- Data for Name: management_admin_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.management_admin_role (id, name, admins_crud, users_crud, buckets_crud, bucket_messages_crud, bucket_admins_crud, billing_prices_crud, event_visibility, created_at) FROM stdin;
\.


--
-- Data for Name: management_event; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.management_event (id, actor_id, actor_type, actor_display_name, action, target_type, target_id, "timestamp", details) FROM stdin;
\.


--
-- Data for Name: management_refresh_token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.management_refresh_token (id, management_user_id, token_hash, expires_at) FROM stdin;
\.


--
-- Data for Name: management_user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.management_user (id, is_super_admin, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: management_user_bio; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.management_user_bio (management_user_id, display_name) FROM stdin;
\.


--
-- Data for Name: management_user_credentials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.management_user_credentials (management_user_id, username, password_hash) FROM stdin;
\.


--
-- Name: linear_migration_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.linear_migration_history_id_seq', 1, true);


--
-- Name: admin_permissions admin_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_pkey PRIMARY KEY (admin_id);


--
-- Name: linear_migration_history linear_migration_history_migration_filename_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.linear_migration_history
    ADD CONSTRAINT linear_migration_history_migration_filename_key UNIQUE (migration_filename);


--
-- Name: linear_migration_history linear_migration_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.linear_migration_history
    ADD CONSTRAINT linear_migration_history_pkey PRIMARY KEY (id);


--
-- Name: management_admin_role management_admin_role_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_admin_role
    ADD CONSTRAINT management_admin_role_name_key UNIQUE (name);


--
-- Name: management_admin_role management_admin_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_admin_role
    ADD CONSTRAINT management_admin_role_pkey PRIMARY KEY (id);


--
-- Name: management_event management_event_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_event
    ADD CONSTRAINT management_event_pkey PRIMARY KEY (id);


--
-- Name: management_refresh_token management_refresh_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_refresh_token
    ADD CONSTRAINT management_refresh_token_pkey PRIMARY KEY (id);


--
-- Name: management_user_bio management_user_bio_display_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_user_bio
    ADD CONSTRAINT management_user_bio_display_name_key UNIQUE (display_name);


--
-- Name: management_user_bio management_user_bio_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_user_bio
    ADD CONSTRAINT management_user_bio_pkey PRIMARY KEY (management_user_id);


--
-- Name: management_user_credentials management_user_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_user_credentials
    ADD CONSTRAINT management_user_credentials_pkey PRIMARY KEY (management_user_id);


--
-- Name: management_user_credentials management_user_credentials_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_user_credentials
    ADD CONSTRAINT management_user_credentials_username_key UNIQUE (username);


--
-- Name: management_user management_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_user
    ADD CONSTRAINT management_user_pkey PRIMARY KEY (id);


--
-- Name: idx_linear_migration_history_applied_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_linear_migration_history_applied_at ON public.linear_migration_history USING btree (applied_at DESC);


--
-- Name: idx_management_event_actor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_management_event_actor ON public.management_event USING btree (actor_id);


--
-- Name: idx_management_event_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_management_event_timestamp ON public.management_event USING btree ("timestamp");


--
-- Name: idx_management_refresh_token_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_management_refresh_token_expires_at ON public.management_refresh_token USING btree (expires_at);


--
-- Name: idx_management_refresh_token_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_management_refresh_token_hash ON public.management_refresh_token USING btree (token_hash);


--
-- Name: idx_management_refresh_token_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_management_refresh_token_user_id ON public.management_refresh_token USING btree (management_user_id);


--
-- Name: idx_one_super_admin; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_one_super_admin ON public.management_user USING btree (is_super_admin) WHERE (is_super_admin = true);


--
-- Name: admin_permissions admin_permissions_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.management_user(id) ON DELETE CASCADE;


--
-- Name: management_refresh_token management_refresh_token_management_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_refresh_token
    ADD CONSTRAINT management_refresh_token_management_user_id_fkey FOREIGN KEY (management_user_id) REFERENCES public.management_user(id) ON DELETE CASCADE;


--
-- Name: management_user_bio management_user_bio_management_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_user_bio
    ADD CONSTRAINT management_user_bio_management_user_id_fkey FOREIGN KEY (management_user_id) REFERENCES public.management_user(id) ON DELETE CASCADE;


--
-- Name: management_user management_user_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_user
    ADD CONSTRAINT management_user_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.management_user(id) ON DELETE SET NULL;


--
-- Name: management_user_credentials management_user_credentials_management_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_user_credentials
    ADD CONSTRAINT management_user_credentials_management_user_id_fkey FOREIGN KEY (management_user_id) REFERENCES public.management_user(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA public TO metaboost_management_migrator;


--
-- Name: TABLE admin_permissions; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.admin_permissions TO metaboost_management_read_write;
GRANT SELECT ON TABLE public.admin_permissions TO metaboost_management_read;


--
-- Name: TABLE linear_migration_history; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.linear_migration_history TO metaboost_management_read_write;
GRANT SELECT ON TABLE public.linear_migration_history TO metaboost_management_read;


--
-- Name: SEQUENCE linear_migration_history_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.linear_migration_history_id_seq TO metaboost_management_read_write;
GRANT SELECT ON SEQUENCE public.linear_migration_history_id_seq TO metaboost_management_read;


--
-- Name: TABLE management_admin_role; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.management_admin_role TO metaboost_management_read_write;
GRANT SELECT ON TABLE public.management_admin_role TO metaboost_management_read;


--
-- Name: TABLE management_event; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.management_event TO metaboost_management_read_write;
GRANT SELECT ON TABLE public.management_event TO metaboost_management_read;


--
-- Name: TABLE management_refresh_token; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.management_refresh_token TO metaboost_management_read_write;
GRANT SELECT ON TABLE public.management_refresh_token TO metaboost_management_read;


--
-- Name: TABLE management_user; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.management_user TO metaboost_management_read_write;
GRANT SELECT ON TABLE public.management_user TO metaboost_management_read;


--
-- Name: TABLE management_user_bio; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.management_user_bio TO metaboost_management_read_write;
GRANT SELECT ON TABLE public.management_user_bio TO metaboost_management_read;


--
-- Name: TABLE management_user_credentials; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.management_user_credentials TO metaboost_management_read_write;
GRANT SELECT ON TABLE public.management_user_credentials TO metaboost_management_read;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE metaboost_management_migrator IN SCHEMA public GRANT ALL ON SEQUENCES TO metaboost_management_read_write;
ALTER DEFAULT PRIVILEGES FOR ROLE metaboost_management_migrator IN SCHEMA public GRANT SELECT ON SEQUENCES TO metaboost_management_read;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE metaboost_management_migrator IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO metaboost_management_read_write;
ALTER DEFAULT PRIVILEGES FOR ROLE metaboost_management_migrator IN SCHEMA public GRANT SELECT ON TABLES TO metaboost_management_read;


--
-- PostgreSQL database dump complete
--




-- Management database linear migration history
INSERT INTO public.linear_migration_history (migration_filename, migration_checksum) VALUES
  ('0001_management_schema.sql', 'c5c6c2e398f06e6834446b346ac92bdadf2103f79ccef4985fe8be8f9f675548')
ON CONFLICT (migration_filename) DO NOTHING;
