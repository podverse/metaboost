-- GENERATED FILE (do not edit) — see scripts/database/generate-linear-baseline.sh

\connect metaboost_app

--
-- PostgreSQL database dump
--


-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: nano_id_v2; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.nano_id_v2 AS character varying(15)
	CONSTRAINT nano_id_v2_len_check CHECK (((VALUE IS NULL) OR ((char_length((VALUE)::text) >= 9) AND (char_length((VALUE)::text) <= 15))));


--
-- Name: server_time_with_default; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.server_time_with_default AS timestamp with time zone DEFAULT now();


--
-- Name: varchar_email; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_email AS character varying(255)
	CONSTRAINT varchar_email_check CHECK (((VALUE)::text ~ '^.+@.+\..+$'::text));


--
-- Name: varchar_medium; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_medium AS character varying(255);


--
-- Name: varchar_password; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_password AS character varying(60);


--
-- Name: varchar_short; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_short AS character varying(50);


--
-- Name: varchar_token_hash; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_token_hash AS character varying(64);


--
-- Name: varchar_token_kind; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_token_kind AS character varying(32);


--
-- Name: varchar_url; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_url AS character varying(2048);


--
-- Name: set_updated_at_field(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_updated_at_field() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at := NOW();
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bucket; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    owner_id uuid NOT NULL,
    name public.varchar_short NOT NULL,
    type public.varchar_short DEFAULT 'rss-network'::character varying NOT NULL,
    is_public boolean DEFAULT false NOT NULL,
    parent_bucket_id uuid,
    id_text public.nano_id_v2 NOT NULL,
    created_at public.server_time_with_default NOT NULL,
    updated_at public.server_time_with_default NOT NULL,
    CONSTRAINT bucket_type_check CHECK (((type)::text = ANY ((ARRAY['rss-network'::character varying, 'rss-channel'::character varying, 'rss-item'::character varying, 'mb-root'::character varying, 'mb-mid'::character varying, 'mb-leaf'::character varying])::text[]))),
    CONSTRAINT chk_bucket_mb_mid_leaf_requires_parent CHECK ((((type)::text <> ALL ((ARRAY['mb-mid'::character varying, 'mb-leaf'::character varying])::text[])) OR (parent_bucket_id IS NOT NULL))),
    CONSTRAINT chk_bucket_mb_root_top_level CHECK ((((type)::text <> 'mb-root'::text) OR (parent_bucket_id IS NULL))),
    CONSTRAINT chk_bucket_rss_item_requires_parent CHECK ((((type)::text <> 'rss-item'::text) OR (parent_bucket_id IS NOT NULL)))
);


--
-- Name: bucket_admin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_admin (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id uuid NOT NULL,
    user_id uuid NOT NULL,
    bucket_crud integer DEFAULT 0 NOT NULL,
    bucket_messages_crud integer DEFAULT 0 NOT NULL,
    bucket_admins_crud integer DEFAULT 2 NOT NULL,
    created_at public.server_time_with_default NOT NULL
);


--
-- Name: bucket_admin_invitation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_admin_invitation (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id uuid NOT NULL,
    token character varying(64) NOT NULL,
    bucket_crud integer DEFAULT 0 NOT NULL,
    bucket_messages_crud integer DEFAULT 0 NOT NULL,
    bucket_admins_crud integer DEFAULT 2 NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    created_at public.server_time_with_default NOT NULL,
    expires_at timestamp without time zone DEFAULT (now() + '7 days'::interval) NOT NULL,
    CONSTRAINT bucket_admin_invitation_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'accepted'::character varying, 'rejected'::character varying])::text[])))
);


--
-- Name: bucket_blocked_app; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_blocked_app (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    root_bucket_id uuid NOT NULL,
    app_id public.varchar_medium NOT NULL,
    app_name_snapshot public.varchar_short,
    created_at public.server_time_with_default NOT NULL
);


--
-- Name: bucket_blocked_sender; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_blocked_sender (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    root_bucket_id uuid NOT NULL,
    sender_guid public.varchar_medium NOT NULL,
    label_snapshot public.varchar_short,
    created_at public.server_time_with_default NOT NULL
);


--
-- Name: bucket_message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_message (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_guid uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id uuid NOT NULL,
    sender_name public.varchar_short,
    body text,
    action public.varchar_short DEFAULT 'boost'::character varying NOT NULL,
    created_at public.server_time_with_default NOT NULL,
    CONSTRAINT bucket_message_action_check CHECK (((action)::text = ANY ((ARRAY['boost'::character varying, 'stream'::character varying])::text[]))),
    CONSTRAINT chk_bucket_message_action_body CHECK (((((action)::text = 'stream'::text) AND (body IS NULL)) OR (((action)::text = 'boost'::text) AND ((body IS NULL) OR (length(btrim(body)) > 0)))))
);


--
-- Name: bucket_message_app_meta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_message_app_meta (
    bucket_message_id uuid NOT NULL,
    app_name public.varchar_short NOT NULL,
    app_version public.varchar_short,
    sender_id public.varchar_medium,
    podcast_index_feed_id integer,
    time_position numeric
);


--
-- Name: bucket_message_value; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_message_value (
    bucket_message_id uuid NOT NULL,
    currency public.varchar_short NOT NULL,
    amount numeric NOT NULL,
    amount_unit public.varchar_short,
    threshold_currency_at_create public.varchar_short,
    threshold_amount_minor_at_create integer
);


--
-- Name: bucket_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_role (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id uuid NOT NULL,
    name public.varchar_short NOT NULL,
    bucket_crud integer NOT NULL,
    bucket_messages_crud integer NOT NULL,
    bucket_admins_crud integer NOT NULL,
    created_at public.server_time_with_default NOT NULL
);


--
-- Name: bucket_rss_channel_info; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_rss_channel_info (
    bucket_id uuid NOT NULL,
    rss_feed_url public.varchar_url NOT NULL,
    rss_podcast_guid public.varchar_medium NOT NULL,
    rss_channel_title public.varchar_medium NOT NULL,
    rss_last_parse_attempt timestamp without time zone,
    rss_last_successful_parse timestamp without time zone,
    rss_verified timestamp without time zone,
    rss_verification_failed_at timestamp without time zone,
    rss_last_parsed_feed_hash public.varchar_medium
);


--
-- Name: bucket_rss_item_info; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_rss_item_info (
    bucket_id uuid NOT NULL,
    parent_rss_channel_bucket_id uuid NOT NULL,
    rss_item_guid public.varchar_url NOT NULL,
    rss_item_pub_date timestamp without time zone NOT NULL,
    orphaned boolean DEFAULT false NOT NULL
);


--
-- Name: bucket_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_settings (
    bucket_id uuid NOT NULL,
    message_body_max_length integer DEFAULT 500 NOT NULL,
    preferred_currency public.varchar_short DEFAULT 'USD'::character varying NOT NULL,
    minimum_message_amount_minor integer DEFAULT 0 NOT NULL,
    CONSTRAINT bucket_settings_message_body_max_length_check CHECK (((message_body_max_length >= 140) AND (message_body_max_length <= 2500))),
    CONSTRAINT bucket_settings_minimum_message_amount_minor_check CHECK (((minimum_message_amount_minor >= 0) AND (minimum_message_amount_minor <= 2147483647)))
);


--
-- Name: global_blocked_app; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.global_blocked_app (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    app_id public.varchar_medium NOT NULL,
    note public.varchar_short,
    created_at public.server_time_with_default NOT NULL
);


--
-- Name: linear_migration_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.linear_migration_history (
    id integer NOT NULL,
    migration_filename character varying(255) NOT NULL,
    migration_checksum character varying(64) NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: linear_migration_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.linear_migration_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: linear_migration_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.linear_migration_history_id_seq OWNED BY public.linear_migration_history.id;


--
-- Name: refresh_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_token (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token_hash public.varchar_token_hash NOT NULL,
    expires_at timestamp without time zone NOT NULL
);


--
-- Name: terms_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.terms_version (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    version_key public.varchar_medium NOT NULL,
    title public.varchar_medium NOT NULL,
    content_hash public.varchar_medium NOT NULL,
    announcement_starts_at timestamp without time zone,
    enforcement_starts_at timestamp without time zone NOT NULL,
    status public.varchar_short NOT NULL,
    created_at public.server_time_with_default NOT NULL,
    updated_at public.server_time_with_default NOT NULL,
    CONSTRAINT chk_terms_version_announcement_before_enforcement CHECK (((announcement_starts_at IS NULL) OR (announcement_starts_at <= enforcement_starts_at))),
    CONSTRAINT terms_version_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'upcoming'::character varying, 'current'::character varying, 'deprecated'::character varying])::text[])))
);


--
-- Name: terms_version_content; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.terms_version_content (
    terms_version_id uuid NOT NULL,
    content_text_en_us text NOT NULL,
    content_text_es text NOT NULL
);


--
-- Name: user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."user" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email_verified_at timestamp without time zone,
    id_text public.nano_id_v2 NOT NULL,
    created_at public.server_time_with_default NOT NULL,
    updated_at public.server_time_with_default NOT NULL
);


--
-- Name: user_bio; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_bio (
    user_id uuid NOT NULL,
    display_name public.varchar_short,
    preferred_currency public.varchar_short
);


--
-- Name: user_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_credentials (
    user_id uuid NOT NULL,
    email public.varchar_email,
    username character varying(50),
    password_hash public.varchar_password NOT NULL,
    CONSTRAINT chk_user_credentials_email_or_username CHECK (((email IS NOT NULL) OR (username IS NOT NULL)))
);


--
-- Name: user_terms_acceptance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_terms_acceptance (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    terms_version_id uuid NOT NULL,
    accepted_at timestamp without time zone NOT NULL,
    acceptance_source public.varchar_short,
    created_at public.server_time_with_default NOT NULL
);


--
-- Name: verification_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.verification_token (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    kind public.varchar_token_kind NOT NULL,
    token_hash public.varchar_token_hash NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    payload jsonb
);


--
-- Name: linear_migration_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.linear_migration_history ALTER COLUMN id SET DEFAULT nextval('public.linear_migration_history_id_seq'::regclass);


--
-- Name: bucket_admin bucket_admin_bucket_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_admin
    ADD CONSTRAINT bucket_admin_bucket_id_user_id_key UNIQUE (bucket_id, user_id);


--
-- Name: bucket_admin_invitation bucket_admin_invitation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_admin_invitation
    ADD CONSTRAINT bucket_admin_invitation_pkey PRIMARY KEY (id);


--
-- Name: bucket_admin_invitation bucket_admin_invitation_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_admin_invitation
    ADD CONSTRAINT bucket_admin_invitation_token_key UNIQUE (token);


--
-- Name: bucket_admin bucket_admin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_admin
    ADD CONSTRAINT bucket_admin_pkey PRIMARY KEY (id);


--
-- Name: bucket_blocked_app bucket_blocked_app_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_blocked_app
    ADD CONSTRAINT bucket_blocked_app_pkey PRIMARY KEY (id);


--
-- Name: bucket_blocked_app bucket_blocked_app_root_bucket_id_app_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_blocked_app
    ADD CONSTRAINT bucket_blocked_app_root_bucket_id_app_id_key UNIQUE (root_bucket_id, app_id);


--
-- Name: bucket_blocked_sender bucket_blocked_sender_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_blocked_sender
    ADD CONSTRAINT bucket_blocked_sender_pkey PRIMARY KEY (id);


--
-- Name: bucket_blocked_sender bucket_blocked_sender_root_bucket_id_sender_guid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_blocked_sender
    ADD CONSTRAINT bucket_blocked_sender_root_bucket_id_sender_guid_key UNIQUE (root_bucket_id, sender_guid);


--
-- Name: bucket_message_app_meta bucket_message_app_meta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_message_app_meta
    ADD CONSTRAINT bucket_message_app_meta_pkey PRIMARY KEY (bucket_message_id);


--
-- Name: bucket_message bucket_message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_message
    ADD CONSTRAINT bucket_message_pkey PRIMARY KEY (id);


--
-- Name: bucket_message_value bucket_message_value_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_message_value
    ADD CONSTRAINT bucket_message_value_pkey PRIMARY KEY (bucket_message_id);


--
-- Name: bucket bucket_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket
    ADD CONSTRAINT bucket_pkey PRIMARY KEY (id);


--
-- Name: bucket_role bucket_role_bucket_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_role
    ADD CONSTRAINT bucket_role_bucket_id_name_key UNIQUE (bucket_id, name);


--
-- Name: bucket_role bucket_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_role
    ADD CONSTRAINT bucket_role_pkey PRIMARY KEY (id);


--
-- Name: bucket_rss_channel_info bucket_rss_channel_info_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_rss_channel_info
    ADD CONSTRAINT bucket_rss_channel_info_pkey PRIMARY KEY (bucket_id);


--
-- Name: bucket_rss_channel_info bucket_rss_channel_info_rss_podcast_guid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_rss_channel_info
    ADD CONSTRAINT bucket_rss_channel_info_rss_podcast_guid_key UNIQUE (rss_podcast_guid);


--
-- Name: bucket_rss_item_info bucket_rss_item_info_parent_rss_channel_bucket_id_rss_item__key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_rss_item_info
    ADD CONSTRAINT bucket_rss_item_info_parent_rss_channel_bucket_id_rss_item__key UNIQUE (parent_rss_channel_bucket_id, rss_item_guid);


--
-- Name: bucket_rss_item_info bucket_rss_item_info_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_rss_item_info
    ADD CONSTRAINT bucket_rss_item_info_pkey PRIMARY KEY (bucket_id);


--
-- Name: bucket_settings bucket_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_settings
    ADD CONSTRAINT bucket_settings_pkey PRIMARY KEY (bucket_id);


--
-- Name: global_blocked_app global_blocked_app_app_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_blocked_app
    ADD CONSTRAINT global_blocked_app_app_id_key UNIQUE (app_id);


--
-- Name: global_blocked_app global_blocked_app_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_blocked_app
    ADD CONSTRAINT global_blocked_app_pkey PRIMARY KEY (id);


--
-- Name: linear_migration_history linear_migration_history_migration_filename_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.linear_migration_history
    ADD CONSTRAINT linear_migration_history_migration_filename_key UNIQUE (migration_filename);


--
-- Name: linear_migration_history linear_migration_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.linear_migration_history
    ADD CONSTRAINT linear_migration_history_pkey PRIMARY KEY (id);


--
-- Name: refresh_token refresh_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_token
    ADD CONSTRAINT refresh_token_pkey PRIMARY KEY (id);


--
-- Name: terms_version_content terms_version_content_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terms_version_content
    ADD CONSTRAINT terms_version_content_pkey PRIMARY KEY (terms_version_id);


--
-- Name: terms_version terms_version_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terms_version
    ADD CONSTRAINT terms_version_pkey PRIMARY KEY (id);


--
-- Name: terms_version terms_version_version_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terms_version
    ADD CONSTRAINT terms_version_version_key_key UNIQUE (version_key);


--
-- Name: user_bio user_bio_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_bio
    ADD CONSTRAINT user_bio_pkey PRIMARY KEY (user_id);


--
-- Name: user_credentials user_credentials_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_email_key UNIQUE (email);


--
-- Name: user_credentials user_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_pkey PRIMARY KEY (user_id);


--
-- Name: user_credentials user_credentials_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_username_key UNIQUE (username);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: user_terms_acceptance user_terms_acceptance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_terms_acceptance
    ADD CONSTRAINT user_terms_acceptance_pkey PRIMARY KEY (id);


--
-- Name: user_terms_acceptance user_terms_acceptance_user_id_terms_version_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_terms_acceptance
    ADD CONSTRAINT user_terms_acceptance_user_id_terms_version_id_key UNIQUE (user_id, terms_version_id);


--
-- Name: verification_token verification_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_token
    ADD CONSTRAINT verification_token_pkey PRIMARY KEY (id);


--
-- Name: idx_bucket_admin_bucket_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_admin_bucket_id ON public.bucket_admin USING btree (bucket_id);


--
-- Name: idx_bucket_admin_invitation_bucket_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_admin_invitation_bucket_id ON public.bucket_admin_invitation USING btree (bucket_id);


--
-- Name: idx_bucket_admin_invitation_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_admin_invitation_status ON public.bucket_admin_invitation USING btree (status);


--
-- Name: idx_bucket_admin_invitation_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_admin_invitation_token ON public.bucket_admin_invitation USING btree (token);


--
-- Name: idx_bucket_admin_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_admin_user_id ON public.bucket_admin USING btree (user_id);


--
-- Name: idx_bucket_blocked_app_app_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_blocked_app_app_id ON public.bucket_blocked_app USING btree (app_id);


--
-- Name: idx_bucket_blocked_app_root_bucket_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_blocked_app_root_bucket_id ON public.bucket_blocked_app USING btree (root_bucket_id);


--
-- Name: idx_bucket_blocked_sender_root_bucket_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_blocked_sender_root_bucket_id ON public.bucket_blocked_sender USING btree (root_bucket_id);


--
-- Name: idx_bucket_id_text; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_bucket_id_text ON public.bucket USING btree (id_text);


--
-- Name: idx_bucket_message_bucket_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_message_bucket_id ON public.bucket_message USING btree (bucket_id);


--
-- Name: idx_bucket_message_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_message_created_at ON public.bucket_message USING btree (created_at);


--
-- Name: idx_bucket_message_message_guid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_bucket_message_message_guid ON public.bucket_message USING btree (message_guid);


--
-- Name: idx_bucket_message_value_amount_unit; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_message_value_amount_unit ON public.bucket_message_value USING btree (amount_unit);


--
-- Name: idx_bucket_message_value_currency; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_message_value_currency ON public.bucket_message_value USING btree (currency);


--
-- Name: idx_bucket_message_value_threshold_amount_minor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_message_value_threshold_amount_minor ON public.bucket_message_value USING btree (threshold_amount_minor_at_create);


--
-- Name: idx_bucket_message_value_threshold_currency; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_message_value_threshold_currency ON public.bucket_message_value USING btree (threshold_currency_at_create);


--
-- Name: idx_bucket_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_owner_id ON public.bucket USING btree (owner_id);


--
-- Name: idx_bucket_parent_bucket_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_parent_bucket_id ON public.bucket USING btree (parent_bucket_id);


--
-- Name: idx_bucket_parent_bucket_id_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_parent_bucket_id_type ON public.bucket USING btree (parent_bucket_id, type);


--
-- Name: idx_bucket_role_bucket_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_role_bucket_id ON public.bucket_role USING btree (bucket_id);


--
-- Name: idx_bucket_rss_item_info_guid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_rss_item_info_guid ON public.bucket_rss_item_info USING btree (rss_item_guid);


--
-- Name: idx_bucket_rss_item_info_parent_channel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_rss_item_info_parent_channel ON public.bucket_rss_item_info USING btree (parent_rss_channel_bucket_id);


--
-- Name: idx_bucket_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_type ON public.bucket USING btree (type);


--
-- Name: idx_global_blocked_app_app_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_global_blocked_app_app_id ON public.global_blocked_app USING btree (app_id);


--
-- Name: idx_linear_migration_history_applied_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_linear_migration_history_applied_at ON public.linear_migration_history USING btree (applied_at DESC);


--
-- Name: idx_refresh_token_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refresh_token_expires_at ON public.refresh_token USING btree (expires_at);


--
-- Name: idx_refresh_token_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_refresh_token_hash ON public.refresh_token USING btree (token_hash);


--
-- Name: idx_refresh_token_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refresh_token_user_id ON public.refresh_token USING btree (user_id);


--
-- Name: idx_terms_version_single_current; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_terms_version_single_current ON public.terms_version USING btree (status) WHERE ((status)::text = 'current'::text);


--
-- Name: idx_terms_version_single_upcoming; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_terms_version_single_upcoming ON public.terms_version USING btree (status) WHERE ((status)::text = 'upcoming'::text);


--
-- Name: idx_terms_version_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_terms_version_status ON public.terms_version USING btree (status);


--
-- Name: idx_user_id_text; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_user_id_text ON public."user" USING btree (id_text);


--
-- Name: idx_user_terms_acceptance_terms_version_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_terms_acceptance_terms_version_id ON public.user_terms_acceptance USING btree (terms_version_id);


--
-- Name: idx_user_terms_acceptance_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_terms_acceptance_user_id ON public.user_terms_acceptance USING btree (user_id);


--
-- Name: idx_verification_token_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_token_expires_at ON public.verification_token USING btree (expires_at);


--
-- Name: idx_verification_token_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_verification_token_hash ON public.verification_token USING btree (token_hash);


--
-- Name: bucket set_updated_at_bucket; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_updated_at_bucket BEFORE UPDATE ON public.bucket FOR EACH ROW EXECUTE FUNCTION public.set_updated_at_field();


--
-- Name: terms_version set_updated_at_terms_version; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_updated_at_terms_version BEFORE UPDATE ON public.terms_version FOR EACH ROW EXECUTE FUNCTION public.set_updated_at_field();


--
-- Name: user set_updated_at_user; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_updated_at_user BEFORE UPDATE ON public."user" FOR EACH ROW EXECUTE FUNCTION public.set_updated_at_field();


--
-- Name: bucket_admin bucket_admin_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_admin
    ADD CONSTRAINT bucket_admin_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: bucket_admin_invitation bucket_admin_invitation_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_admin_invitation
    ADD CONSTRAINT bucket_admin_invitation_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: bucket_admin bucket_admin_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_admin
    ADD CONSTRAINT bucket_admin_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: bucket_blocked_app bucket_blocked_app_root_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_blocked_app
    ADD CONSTRAINT bucket_blocked_app_root_bucket_id_fkey FOREIGN KEY (root_bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: bucket_blocked_sender bucket_blocked_sender_root_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_blocked_sender
    ADD CONSTRAINT bucket_blocked_sender_root_bucket_id_fkey FOREIGN KEY (root_bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: bucket_message_app_meta bucket_message_app_meta_bucket_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_message_app_meta
    ADD CONSTRAINT bucket_message_app_meta_bucket_message_id_fkey FOREIGN KEY (bucket_message_id) REFERENCES public.bucket_message(id) ON DELETE CASCADE;


--
-- Name: bucket_message bucket_message_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_message
    ADD CONSTRAINT bucket_message_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: bucket_message_value bucket_message_value_bucket_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_message_value
    ADD CONSTRAINT bucket_message_value_bucket_message_id_fkey FOREIGN KEY (bucket_message_id) REFERENCES public.bucket_message(id) ON DELETE CASCADE;


--
-- Name: bucket bucket_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket
    ADD CONSTRAINT bucket_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: bucket bucket_parent_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket
    ADD CONSTRAINT bucket_parent_bucket_id_fkey FOREIGN KEY (parent_bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: bucket_role bucket_role_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_role
    ADD CONSTRAINT bucket_role_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: bucket_rss_channel_info bucket_rss_channel_info_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_rss_channel_info
    ADD CONSTRAINT bucket_rss_channel_info_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: bucket_rss_item_info bucket_rss_item_info_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_rss_item_info
    ADD CONSTRAINT bucket_rss_item_info_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: bucket_rss_item_info bucket_rss_item_info_parent_rss_channel_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_rss_item_info
    ADD CONSTRAINT bucket_rss_item_info_parent_rss_channel_bucket_id_fkey FOREIGN KEY (parent_rss_channel_bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: bucket_settings bucket_settings_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_settings
    ADD CONSTRAINT bucket_settings_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: refresh_token refresh_token_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_token
    ADD CONSTRAINT refresh_token_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: terms_version_content terms_version_content_terms_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terms_version_content
    ADD CONSTRAINT terms_version_content_terms_version_id_fkey FOREIGN KEY (terms_version_id) REFERENCES public.terms_version(id) ON DELETE CASCADE;


--
-- Name: user_bio user_bio_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_bio
    ADD CONSTRAINT user_bio_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: user_credentials user_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: user_terms_acceptance user_terms_acceptance_terms_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_terms_acceptance
    ADD CONSTRAINT user_terms_acceptance_terms_version_id_fkey FOREIGN KEY (terms_version_id) REFERENCES public.terms_version(id) ON DELETE CASCADE;


--
-- Name: user_terms_acceptance user_terms_acceptance_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_terms_acceptance
    ADD CONSTRAINT user_terms_acceptance_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: verification_token verification_token_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_token
    ADD CONSTRAINT verification_token_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA public TO metaboost_app_read;
GRANT USAGE ON SCHEMA public TO metaboost_app_read_write;


--
-- Name: TABLE bucket; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.bucket TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket TO metaboost_app_read_write;


--
-- Name: TABLE bucket_admin; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.bucket_admin TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_admin TO metaboost_app_read_write;


--
-- Name: TABLE bucket_admin_invitation; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.bucket_admin_invitation TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_admin_invitation TO metaboost_app_read_write;


--
-- Name: TABLE bucket_blocked_app; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.bucket_blocked_app TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_blocked_app TO metaboost_app_read_write;


--
-- Name: TABLE bucket_blocked_sender; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.bucket_blocked_sender TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_blocked_sender TO metaboost_app_read_write;


--
-- Name: TABLE bucket_message; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.bucket_message TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_message TO metaboost_app_read_write;


--
-- Name: TABLE bucket_message_app_meta; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.bucket_message_app_meta TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_message_app_meta TO metaboost_app_read_write;


--
-- Name: TABLE bucket_message_value; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.bucket_message_value TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_message_value TO metaboost_app_read_write;


--
-- Name: TABLE bucket_role; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.bucket_role TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_role TO metaboost_app_read_write;


--
-- Name: TABLE bucket_rss_channel_info; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.bucket_rss_channel_info TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_rss_channel_info TO metaboost_app_read_write;


--
-- Name: TABLE bucket_rss_item_info; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.bucket_rss_item_info TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_rss_item_info TO metaboost_app_read_write;


--
-- Name: TABLE bucket_settings; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.bucket_settings TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_settings TO metaboost_app_read_write;


--
-- Name: TABLE global_blocked_app; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.global_blocked_app TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.global_blocked_app TO metaboost_app_read_write;


--
-- Name: TABLE linear_migration_history; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.linear_migration_history TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.linear_migration_history TO metaboost_app_read_write;


--
-- Name: SEQUENCE linear_migration_history_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON SEQUENCE public.linear_migration_history_id_seq TO metaboost_app_read;
GRANT ALL ON SEQUENCE public.linear_migration_history_id_seq TO metaboost_app_read_write;


--
-- Name: TABLE refresh_token; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.refresh_token TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.refresh_token TO metaboost_app_read_write;


--
-- Name: TABLE terms_version; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.terms_version TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.terms_version TO metaboost_app_read_write;


--
-- Name: TABLE terms_version_content; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.terms_version_content TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.terms_version_content TO metaboost_app_read_write;


--
-- Name: TABLE "user"; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public."user" TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public."user" TO metaboost_app_read_write;


--
-- Name: TABLE user_bio; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.user_bio TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.user_bio TO metaboost_app_read_write;


--
-- Name: TABLE user_credentials; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.user_credentials TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.user_credentials TO metaboost_app_read_write;


--
-- Name: TABLE user_terms_acceptance; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.user_terms_acceptance TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.user_terms_acceptance TO metaboost_app_read_write;


--
-- Name: TABLE verification_token; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.verification_token TO metaboost_app_read;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.verification_token TO metaboost_app_read_write;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT ON SEQUENCES TO metaboost_app_read;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO metaboost_app_read_write;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT ON TABLES TO metaboost_app_read;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLES TO metaboost_app_read_write;


--
-- PostgreSQL database dump complete
--



\connect metaboost_management

--
-- PostgreSQL database dump
--


-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: server_time_with_default; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.server_time_with_default AS timestamp with time zone DEFAULT now();


--
-- Name: varchar_password; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_password AS character varying(60);


--
-- Name: varchar_short; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_short AS character varying(50);


--
-- Name: varchar_token_hash; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_token_hash AS character varying(64);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_permissions (
    admin_id uuid NOT NULL,
    admins_crud integer DEFAULT 0 NOT NULL,
    users_crud integer DEFAULT 0 NOT NULL,
    buckets_crud integer DEFAULT 0 NOT NULL,
    bucket_messages_crud integer DEFAULT 0 NOT NULL,
    bucket_admins_crud integer DEFAULT 0 NOT NULL,
    event_visibility text DEFAULT 'all_admins'::text NOT NULL,
    CONSTRAINT admin_permissions_admins_crud_check CHECK (((admins_crud >= 0) AND (admins_crud <= 15))),
    CONSTRAINT admin_permissions_bucket_admins_crud_check CHECK (((bucket_admins_crud >= 0) AND (bucket_admins_crud <= 15))),
    CONSTRAINT admin_permissions_bucket_messages_crud_check CHECK (((bucket_messages_crud >= 0) AND (bucket_messages_crud <= 15))),
    CONSTRAINT admin_permissions_buckets_crud_check CHECK (((buckets_crud >= 0) AND (buckets_crud <= 15))),
    CONSTRAINT admin_permissions_event_visibility_check CHECK ((event_visibility = ANY (ARRAY['own'::text, 'all_admins'::text, 'all'::text]))),
    CONSTRAINT admin_permissions_users_crud_check CHECK (((users_crud >= 0) AND (users_crud <= 15)))
);


--
-- Name: linear_migration_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.linear_migration_history (
    id integer NOT NULL,
    migration_filename character varying(255) NOT NULL,
    migration_checksum character varying(64) NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: linear_migration_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.linear_migration_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: linear_migration_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.linear_migration_history_id_seq OWNED BY public.linear_migration_history.id;


--
-- Name: management_admin_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.management_admin_role (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name public.varchar_short NOT NULL,
    admins_crud integer NOT NULL,
    users_crud integer NOT NULL,
    buckets_crud integer NOT NULL,
    bucket_messages_crud integer NOT NULL,
    bucket_admins_crud integer NOT NULL,
    event_visibility text NOT NULL,
    created_at public.server_time_with_default NOT NULL,
    CONSTRAINT management_admin_role_admins_crud_check CHECK (((admins_crud >= 0) AND (admins_crud <= 15))),
    CONSTRAINT management_admin_role_bucket_admins_crud_check CHECK (((bucket_admins_crud >= 0) AND (bucket_admins_crud <= 15))),
    CONSTRAINT management_admin_role_bucket_messages_crud_check CHECK (((bucket_messages_crud >= 0) AND (bucket_messages_crud <= 15))),
    CONSTRAINT management_admin_role_buckets_crud_check CHECK (((buckets_crud >= 0) AND (buckets_crud <= 15))),
    CONSTRAINT management_admin_role_event_visibility_check CHECK ((event_visibility = ANY (ARRAY['own'::text, 'all_admins'::text, 'all'::text]))),
    CONSTRAINT management_admin_role_users_crud_check CHECK (((users_crud >= 0) AND (users_crud <= 15)))
);


--
-- Name: management_event; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.management_event (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor_id text NOT NULL,
    actor_type text NOT NULL,
    actor_display_name text,
    action text NOT NULL,
    target_type text,
    target_id text,
    "timestamp" public.server_time_with_default NOT NULL,
    details text,
    CONSTRAINT management_event_actor_type_check CHECK ((actor_type = ANY (ARRAY['super_admin'::text, 'admin'::text])))
);


--
-- Name: management_refresh_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.management_refresh_token (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    management_user_id uuid NOT NULL,
    token_hash public.varchar_token_hash NOT NULL,
    expires_at timestamp without time zone NOT NULL
);


--
-- Name: management_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.management_user (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    is_super_admin boolean DEFAULT false NOT NULL,
    created_at public.server_time_with_default NOT NULL,
    created_by uuid
);


--
-- Name: management_user_bio; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.management_user_bio (
    management_user_id uuid NOT NULL,
    display_name public.varchar_short NOT NULL
);


--
-- Name: management_user_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.management_user_credentials (
    management_user_id uuid NOT NULL,
    username public.varchar_short NOT NULL,
    password_hash public.varchar_password NOT NULL
);


--
-- Name: linear_migration_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.linear_migration_history ALTER COLUMN id SET DEFAULT nextval('public.linear_migration_history_id_seq'::regclass);


--
-- Name: admin_permissions admin_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_pkey PRIMARY KEY (admin_id);


--
-- Name: linear_migration_history linear_migration_history_migration_filename_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.linear_migration_history
    ADD CONSTRAINT linear_migration_history_migration_filename_key UNIQUE (migration_filename);


--
-- Name: linear_migration_history linear_migration_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.linear_migration_history
    ADD CONSTRAINT linear_migration_history_pkey PRIMARY KEY (id);


--
-- Name: management_admin_role management_admin_role_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_admin_role
    ADD CONSTRAINT management_admin_role_name_key UNIQUE (name);


--
-- Name: management_admin_role management_admin_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_admin_role
    ADD CONSTRAINT management_admin_role_pkey PRIMARY KEY (id);


--
-- Name: management_event management_event_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_event
    ADD CONSTRAINT management_event_pkey PRIMARY KEY (id);


--
-- Name: management_refresh_token management_refresh_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_refresh_token
    ADD CONSTRAINT management_refresh_token_pkey PRIMARY KEY (id);


--
-- Name: management_user_bio management_user_bio_display_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_user_bio
    ADD CONSTRAINT management_user_bio_display_name_key UNIQUE (display_name);


--
-- Name: management_user_bio management_user_bio_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_user_bio
    ADD CONSTRAINT management_user_bio_pkey PRIMARY KEY (management_user_id);


--
-- Name: management_user_credentials management_user_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_user_credentials
    ADD CONSTRAINT management_user_credentials_pkey PRIMARY KEY (management_user_id);


--
-- Name: management_user_credentials management_user_credentials_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_user_credentials
    ADD CONSTRAINT management_user_credentials_username_key UNIQUE (username);


--
-- Name: management_user management_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_user
    ADD CONSTRAINT management_user_pkey PRIMARY KEY (id);


--
-- Name: idx_linear_migration_history_applied_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_linear_migration_history_applied_at ON public.linear_migration_history USING btree (applied_at DESC);


--
-- Name: idx_management_event_actor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_management_event_actor ON public.management_event USING btree (actor_id);


--
-- Name: idx_management_event_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_management_event_timestamp ON public.management_event USING btree ("timestamp");


--
-- Name: idx_management_refresh_token_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_management_refresh_token_expires_at ON public.management_refresh_token USING btree (expires_at);


--
-- Name: idx_management_refresh_token_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_management_refresh_token_hash ON public.management_refresh_token USING btree (token_hash);


--
-- Name: idx_management_refresh_token_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_management_refresh_token_user_id ON public.management_refresh_token USING btree (management_user_id);


--
-- Name: idx_one_super_admin; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_one_super_admin ON public.management_user USING btree (is_super_admin) WHERE (is_super_admin = true);


--
-- Name: admin_permissions admin_permissions_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.management_user(id) ON DELETE CASCADE;


--
-- Name: management_refresh_token management_refresh_token_management_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_refresh_token
    ADD CONSTRAINT management_refresh_token_management_user_id_fkey FOREIGN KEY (management_user_id) REFERENCES public.management_user(id) ON DELETE CASCADE;


--
-- Name: management_user_bio management_user_bio_management_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_user_bio
    ADD CONSTRAINT management_user_bio_management_user_id_fkey FOREIGN KEY (management_user_id) REFERENCES public.management_user(id) ON DELETE CASCADE;


--
-- Name: management_user management_user_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_user
    ADD CONSTRAINT management_user_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.management_user(id) ON DELETE SET NULL;


--
-- Name: management_user_credentials management_user_credentials_management_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.management_user_credentials
    ADD CONSTRAINT management_user_credentials_management_user_id_fkey FOREIGN KEY (management_user_id) REFERENCES public.management_user(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--



