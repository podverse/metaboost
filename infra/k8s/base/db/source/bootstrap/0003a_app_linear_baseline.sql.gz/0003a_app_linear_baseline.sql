-- GENERATED FILE (do not edit) — see scripts/database/generate-linear-baseline.sh

-- App database baseline (schema + migration-materialized data; applied as DB_APP_MIGRATOR_USER).

-- linear_migration_history data is appended deterministically from migration filenames + checksums.

--
-- PostgreSQL database dump
--


-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3 (Debian 18.3-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: nano_id_v2; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.nano_id_v2 AS character varying(15)
	CONSTRAINT nano_id_v2_len_check CHECK (((VALUE IS NULL) OR ((char_length((VALUE)::text) >= 9) AND (char_length((VALUE)::text) <= 15))));


--
-- Name: server_time_with_default; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.server_time_with_default AS timestamp with time zone DEFAULT now();


--
-- Name: varchar_email; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_email AS character varying(255)
	CONSTRAINT varchar_email_check CHECK (((VALUE)::text ~ '^.+@.+\..+$'::text));


--
-- Name: varchar_medium; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_medium AS character varying(255);


--
-- Name: varchar_password; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_password AS character varying(60);


--
-- Name: varchar_short; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_short AS character varying(50);


--
-- Name: varchar_token_hash; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_token_hash AS character varying(64);


--
-- Name: varchar_token_kind; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_token_kind AS character varying(32);


--
-- Name: varchar_url; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_url AS character varying(2048);


--
-- Name: set_updated_at_field(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_updated_at_field() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at := NOW();
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: billing_domain_event; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.billing_domain_event (
    id integer NOT NULL,
    event_type text NOT NULL,
    user_id uuid NOT NULL,
    idempotency_key character varying(128),
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at public.server_time_with_default NOT NULL,
    CONSTRAINT billing_domain_event_event_type_check CHECK ((event_type = ANY (ARRAY['payment_settled'::text, 'renewal_succeeded'::text, 'renewal_failed'::text, 'pay_on_demand_extension_requested'::text])))
);


--
-- Name: billing_domain_event_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.billing_domain_event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: billing_domain_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.billing_domain_event_id_seq OWNED BY public.billing_domain_event.id;


--
-- Name: billing_price; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.billing_price (
    id integer NOT NULL,
    billing_product_id integer NOT NULL,
    currency_code character(3) NOT NULL,
    billing_cadence text NOT NULL,
    amount_cents integer NOT NULL,
    effective_from timestamp without time zone DEFAULT now() NOT NULL,
    effective_to timestamp without time zone,
    source text DEFAULT 'manual'::text NOT NULL,
    created_at public.server_time_with_default NOT NULL,
    updated_at public.server_time_with_default NOT NULL,
    CONSTRAINT billing_price_amount_cents_check CHECK ((amount_cents >= 0)),
    CONSTRAINT billing_price_billing_cadence_check CHECK ((billing_cadence = ANY (ARRAY['monthly'::text, 'annual'::text]))),
    CONSTRAINT billing_price_effective_window_check CHECK (((effective_to IS NULL) OR (effective_to > effective_from)))
);


--
-- Name: billing_price_change_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.billing_price_change_audit (
    id integer NOT NULL,
    billing_price_id integer,
    changed_by_management_user_id uuid,
    change_reason text,
    previous_amount_cents integer,
    new_amount_cents integer,
    previous_effective_from timestamp without time zone,
    previous_effective_to timestamp without time zone,
    new_effective_from timestamp without time zone,
    new_effective_to timestamp without time zone,
    created_at public.server_time_with_default NOT NULL,
    CONSTRAINT billing_price_change_audit_new_amount_cents_check CHECK (((new_amount_cents IS NULL) OR (new_amount_cents >= 0))),
    CONSTRAINT billing_price_change_audit_previous_amount_cents_check CHECK (((previous_amount_cents IS NULL) OR (previous_amount_cents >= 0)))
);


--
-- Name: billing_price_change_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.billing_price_change_audit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: billing_price_change_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.billing_price_change_audit_id_seq OWNED BY public.billing_price_change_audit.id;


--
-- Name: billing_price_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.billing_price_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: billing_price_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.billing_price_id_seq OWNED BY public.billing_price.id;


--
-- Name: billing_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.billing_product (
    id integer NOT NULL,
    product_code text NOT NULL,
    name text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at public.server_time_with_default NOT NULL,
    updated_at public.server_time_with_default NOT NULL
);


--
-- Name: billing_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.billing_product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: billing_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.billing_product_id_seq OWNED BY public.billing_product.id;


--
-- Name: bucket; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    owner_id uuid NOT NULL,
    name public.varchar_short NOT NULL,
    type public.varchar_short DEFAULT 'rss-network'::character varying NOT NULL,
    is_public boolean DEFAULT false NOT NULL,
    parent_bucket_id uuid,
    id_text public.nano_id_v2 NOT NULL,
    created_at public.server_time_with_default NOT NULL,
    updated_at public.server_time_with_default NOT NULL,
    CONSTRAINT bucket_type_check CHECK (((type)::text = ANY ((ARRAY['rss-network'::character varying, 'rss-channel'::character varying, 'rss-item'::character varying, 'mb-root'::character varying, 'mb-mid'::character varying, 'mb-leaf'::character varying])::text[]))),
    CONSTRAINT chk_bucket_mb_mid_leaf_requires_parent CHECK ((((type)::text <> ALL ((ARRAY['mb-mid'::character varying, 'mb-leaf'::character varying])::text[])) OR (parent_bucket_id IS NOT NULL))),
    CONSTRAINT chk_bucket_mb_root_top_level CHECK ((((type)::text <> 'mb-root'::text) OR (parent_bucket_id IS NULL))),
    CONSTRAINT chk_bucket_rss_item_requires_parent CHECK ((((type)::text <> 'rss-item'::text) OR (parent_bucket_id IS NOT NULL)))
);


--
-- Name: bucket_admin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_admin (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id uuid NOT NULL,
    user_id uuid NOT NULL,
    bucket_crud integer DEFAULT 0 NOT NULL,
    bucket_messages_crud integer DEFAULT 0 NOT NULL,
    bucket_admins_crud integer DEFAULT 2 NOT NULL,
    created_at public.server_time_with_default NOT NULL
);


--
-- Name: bucket_admin_invitation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_admin_invitation (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id uuid NOT NULL,
    token character varying(64) NOT NULL,
    bucket_crud integer DEFAULT 0 NOT NULL,
    bucket_messages_crud integer DEFAULT 0 NOT NULL,
    bucket_admins_crud integer DEFAULT 2 NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    created_at public.server_time_with_default NOT NULL,
    expires_at timestamp without time zone DEFAULT (now() + '7 days'::interval) NOT NULL,
    CONSTRAINT bucket_admin_invitation_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'accepted'::character varying, 'rejected'::character varying])::text[])))
);


--
-- Name: bucket_blocked_app; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_blocked_app (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    root_bucket_id uuid NOT NULL,
    app_id public.varchar_medium NOT NULL,
    app_name_snapshot public.varchar_short,
    created_at public.server_time_with_default NOT NULL
);


--
-- Name: bucket_blocked_sender; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_blocked_sender (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    root_bucket_id uuid NOT NULL,
    sender_guid public.varchar_medium NOT NULL,
    label_snapshot public.varchar_short,
    created_at public.server_time_with_default NOT NULL
);


--
-- Name: bucket_message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_message (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_guid uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id uuid NOT NULL,
    sender_name public.varchar_short,
    body text,
    action public.varchar_short DEFAULT 'boost'::character varying NOT NULL,
    created_at public.server_time_with_default NOT NULL,
    CONSTRAINT bucket_message_action_check CHECK (((action)::text = ANY ((ARRAY['boost'::character varying, 'stream'::character varying])::text[]))),
    CONSTRAINT chk_bucket_message_action_body CHECK (((((action)::text = 'stream'::text) AND (body IS NULL)) OR (((action)::text = 'boost'::text) AND ((body IS NULL) OR (length(btrim(body)) > 0)))))
);


--
-- Name: bucket_message_app_meta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_message_app_meta (
    bucket_message_id uuid NOT NULL,
    app_name public.varchar_short NOT NULL,
    app_version public.varchar_short,
    sender_id public.varchar_medium,
    podcast_index_feed_id integer,
    time_position numeric
);


--
-- Name: bucket_message_value; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_message_value (
    bucket_message_id uuid NOT NULL,
    currency public.varchar_short NOT NULL,
    amount numeric NOT NULL,
    amount_unit public.varchar_short,
    threshold_currency_at_create public.varchar_short,
    threshold_amount_minor_at_create integer
);


--
-- Name: bucket_notification_preference; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_notification_preference (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    bucket_id uuid NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at public.server_time_with_default NOT NULL,
    updated_at public.server_time_with_default NOT NULL
);


--
-- Name: bucket_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_role (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id uuid NOT NULL,
    name public.varchar_short NOT NULL,
    bucket_crud integer NOT NULL,
    bucket_messages_crud integer NOT NULL,
    bucket_admins_crud integer NOT NULL,
    created_at public.server_time_with_default NOT NULL
);


--
-- Name: bucket_rss_channel_info; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_rss_channel_info (
    bucket_id uuid NOT NULL,
    rss_feed_url public.varchar_url NOT NULL,
    rss_podcast_guid public.varchar_medium NOT NULL,
    rss_channel_title public.varchar_medium NOT NULL,
    rss_last_parse_attempt timestamp without time zone,
    rss_last_successful_parse timestamp without time zone,
    rss_verified timestamp without time zone,
    rss_verification_failed_at timestamp without time zone,
    rss_last_parsed_feed_hash public.varchar_medium
);


--
-- Name: bucket_rss_item_info; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_rss_item_info (
    bucket_id uuid NOT NULL,
    parent_rss_channel_bucket_id uuid NOT NULL,
    rss_item_guid public.varchar_url NOT NULL,
    rss_item_pub_date timestamp without time zone NOT NULL,
    orphaned boolean DEFAULT false NOT NULL
);


--
-- Name: bucket_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bucket_settings (
    bucket_id uuid NOT NULL,
    message_body_max_length integer DEFAULT 500 NOT NULL,
    preferred_currency public.varchar_short DEFAULT 'USD'::character varying NOT NULL,
    public_boost_display_minimum_minor integer DEFAULT 0 NOT NULL,
    CONSTRAINT bucket_settings_message_body_max_length_check CHECK (((message_body_max_length >= 140) AND (message_body_max_length <= 2500))),
    CONSTRAINT bucket_settings_public_boost_display_minimum_minor_check CHECK (((public_boost_display_minimum_minor >= 0) AND (public_boost_display_minimum_minor <= 2147483647)))
);


--
-- Name: global_blocked_app; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.global_blocked_app (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    app_id public.varchar_medium NOT NULL,
    note public.varchar_short,
    created_at public.server_time_with_default NOT NULL
);


--
-- Name: linear_migration_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.linear_migration_history (
    id integer NOT NULL,
    migration_filename character varying(255) NOT NULL,
    migration_checksum character varying(64) NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: linear_migration_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.linear_migration_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: linear_migration_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.linear_migration_history_id_seq OWNED BY public.linear_migration_history.id;


--
-- Name: product_membership_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_membership_settings (
    id integer DEFAULT 1 NOT NULL,
    free_trial_expiration_seconds integer CONSTRAINT product_membership_settings_free_trial_expiration_seco_not_null NOT NULL,
    created_at public.server_time_with_default NOT NULL,
    updated_at public.server_time_with_default NOT NULL,
    CONSTRAINT product_membership_settings_free_trial_expiration_seconds_check CHECK ((free_trial_expiration_seconds > 0)),
    CONSTRAINT product_membership_settings_id_check CHECK ((id = 1))
);


--
-- Name: refresh_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_token (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token_hash public.varchar_token_hash NOT NULL,
    expires_at timestamp without time zone NOT NULL
);


--
-- Name: terms_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.terms_version (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    version_key public.varchar_medium NOT NULL,
    title public.varchar_medium NOT NULL,
    content_hash public.varchar_medium NOT NULL,
    announcement_starts_at timestamp without time zone,
    enforcement_starts_at timestamp without time zone NOT NULL,
    status public.varchar_short NOT NULL,
    created_at public.server_time_with_default NOT NULL,
    updated_at public.server_time_with_default NOT NULL,
    CONSTRAINT chk_terms_version_announcement_before_enforcement CHECK (((announcement_starts_at IS NULL) OR (announcement_starts_at <= enforcement_starts_at))),
    CONSTRAINT terms_version_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'upcoming'::character varying, 'current'::character varying, 'deprecated'::character varying])::text[])))
);


--
-- Name: terms_version_content; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.terms_version_content (
    terms_version_id uuid NOT NULL,
    content_text_en_us text NOT NULL,
    content_text_es text NOT NULL
);


--
-- Name: user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."user" (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email_verified_at timestamp without time zone,
    id_text public.nano_id_v2 NOT NULL,
    created_at public.server_time_with_default NOT NULL,
    updated_at public.server_time_with_default NOT NULL
);


--
-- Name: user_bio; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_bio (
    user_id uuid NOT NULL,
    display_name public.varchar_short,
    preferred_currency public.varchar_short
);


--
-- Name: user_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_credentials (
    user_id uuid NOT NULL,
    email public.varchar_email,
    username character varying(50),
    password_hash public.varchar_password NOT NULL,
    CONSTRAINT chk_user_credentials_email_or_username CHECK (((email IS NOT NULL) OR (username IS NOT NULL)))
);


--
-- Name: user_terms_acceptance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_terms_acceptance (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    terms_version_id uuid NOT NULL,
    accepted_at timestamp without time zone NOT NULL,
    acceptance_source public.varchar_short,
    created_at public.server_time_with_default NOT NULL
);


--
-- Name: user_trust_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_trust_settings (
    user_id uuid NOT NULL,
    membership_tier character varying(32) DEFAULT 'trial'::character varying NOT NULL,
    membership_expires_at timestamp without time zone,
    auto_renew boolean DEFAULT false NOT NULL,
    created_at public.server_time_with_default NOT NULL,
    updated_at public.server_time_with_default NOT NULL,
    billing_cadence text,
    auto_renew_mode text DEFAULT 'off'::text NOT NULL,
    next_renewal_attempt_at timestamp without time zone,
    last_renewal_attempt_at timestamp without time zone,
    last_renewal_status text DEFAULT 'none'::text NOT NULL,
    last_extension_idempotency_key character varying(128),
    last_renewal_idempotency_key character varying(128),
    renewal_retry_count integer DEFAULT 0 NOT NULL,
    renewal_retry_backoff_until timestamp without time zone,
    CONSTRAINT chk_user_trust_settings_membership_expires_after_epoch CHECK (((membership_expires_at IS NULL) OR (membership_expires_at > '1970-01-01 00:00:00'::timestamp without time zone))),
    CONSTRAINT chk_user_trust_settings_membership_tier CHECK (((membership_tier)::text = ANY ((ARRAY['trial'::character varying, 'premium'::character varying])::text[]))),
    CONSTRAINT user_trust_settings_auto_renew_mode_check CHECK ((auto_renew_mode = ANY (ARRAY['off'::text, 'on'::text]))),
    CONSTRAINT user_trust_settings_billing_cadence_check CHECK (((billing_cadence IS NULL) OR (billing_cadence = ANY (ARRAY['monthly'::text, 'annual'::text])))),
    CONSTRAINT user_trust_settings_last_renewal_status_check CHECK ((last_renewal_status = ANY (ARRAY['none'::text, 'succeeded'::text, 'failed'::text])))
);


--
-- Name: user_web_push_subscription; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_web_push_subscription (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    endpoint public.varchar_url NOT NULL,
    key_p256dh text NOT NULL,
    key_auth text NOT NULL,
    locale public.varchar_short,
    created_at public.server_time_with_default NOT NULL,
    updated_at public.server_time_with_default NOT NULL
);


--
-- Name: verification_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.verification_token (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    kind public.varchar_token_kind NOT NULL,
    token_hash public.varchar_token_hash NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    payload jsonb
);


--
-- Name: billing_domain_event id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_domain_event ALTER COLUMN id SET DEFAULT nextval('public.billing_domain_event_id_seq'::regclass);


--
-- Name: billing_price id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_price ALTER COLUMN id SET DEFAULT nextval('public.billing_price_id_seq'::regclass);


--
-- Name: billing_price_change_audit id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_price_change_audit ALTER COLUMN id SET DEFAULT nextval('public.billing_price_change_audit_id_seq'::regclass);


--
-- Name: billing_product id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_product ALTER COLUMN id SET DEFAULT nextval('public.billing_product_id_seq'::regclass);


--
-- Name: linear_migration_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.linear_migration_history ALTER COLUMN id SET DEFAULT nextval('public.linear_migration_history_id_seq'::regclass);


--
-- Data for Name: billing_domain_event; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.billing_domain_event (id, event_type, user_id, idempotency_key, payload, created_at) FROM stdin;
\.


--
-- Data for Name: billing_price; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.billing_price (id, billing_product_id, currency_code, billing_cadence, amount_cents, effective_from, effective_to, source, created_at, updated_at) FROM stdin;
1	1	USD	monthly	300	2000-01-01 00:00:00	\N	seed	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
2	1	USD	annual	3000	2000-01-01 00:00:00	\N	seed	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
\.


--
-- Data for Name: billing_price_change_audit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.billing_price_change_audit (id, billing_price_id, changed_by_management_user_id, change_reason, previous_amount_cents, new_amount_cents, previous_effective_from, previous_effective_to, new_effective_from, new_effective_to, created_at) FROM stdin;
\.


--
-- Data for Name: billing_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.billing_product (id, product_code, name, is_active, created_at, updated_at) FROM stdin;
1	membership_premium	Premium Membership	t	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
\.


--
-- Data for Name: bucket; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bucket (id, owner_id, name, type, is_public, parent_bucket_id, id_text, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bucket_admin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bucket_admin (id, bucket_id, user_id, bucket_crud, bucket_messages_crud, bucket_admins_crud, created_at) FROM stdin;
\.


--
-- Data for Name: bucket_admin_invitation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bucket_admin_invitation (id, bucket_id, token, bucket_crud, bucket_messages_crud, bucket_admins_crud, status, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: bucket_blocked_app; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bucket_blocked_app (id, root_bucket_id, app_id, app_name_snapshot, created_at) FROM stdin;
\.


--
-- Data for Name: bucket_blocked_sender; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bucket_blocked_sender (id, root_bucket_id, sender_guid, label_snapshot, created_at) FROM stdin;
\.


--
-- Data for Name: bucket_message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bucket_message (id, message_guid, bucket_id, sender_name, body, action, created_at) FROM stdin;
\.


--
-- Data for Name: bucket_message_app_meta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bucket_message_app_meta (bucket_message_id, app_name, app_version, sender_id, podcast_index_feed_id, time_position) FROM stdin;
\.


--
-- Data for Name: bucket_message_value; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bucket_message_value (bucket_message_id, currency, amount, amount_unit, threshold_currency_at_create, threshold_amount_minor_at_create) FROM stdin;
\.


--
-- Data for Name: bucket_notification_preference; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bucket_notification_preference (id, user_id, bucket_id, enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bucket_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bucket_role (id, bucket_id, name, bucket_crud, bucket_messages_crud, bucket_admins_crud, created_at) FROM stdin;
\.


--
-- Data for Name: bucket_rss_channel_info; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bucket_rss_channel_info (bucket_id, rss_feed_url, rss_podcast_guid, rss_channel_title, rss_last_parse_attempt, rss_last_successful_parse, rss_verified, rss_verification_failed_at, rss_last_parsed_feed_hash) FROM stdin;
\.


--
-- Data for Name: bucket_rss_item_info; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bucket_rss_item_info (bucket_id, parent_rss_channel_bucket_id, rss_item_guid, rss_item_pub_date, orphaned) FROM stdin;
\.


--
-- Data for Name: bucket_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bucket_settings (bucket_id, message_body_max_length, preferred_currency, public_boost_display_minimum_minor) FROM stdin;
\.


--
-- Data for Name: global_blocked_app; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.global_blocked_app (id, app_id, note, created_at) FROM stdin;
\.


--
-- Data for Name: product_membership_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_membership_settings (id, free_trial_expiration_seconds, created_at, updated_at) FROM stdin;
1	2678400	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
\.


--
-- Data for Name: refresh_token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refresh_token (id, user_id, token_hash, expires_at) FROM stdin;
\.


--
-- Data for Name: terms_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.terms_version (id, version_key, title, content_hash, announcement_starts_at, enforcement_starts_at, status, created_at, updated_at) FROM stdin;
a0000000-0000-4000-8000-000000000001	default-bootstrap-2026-01-01	Agree to Terms of Service	8a29355eaba9fb246479f5db3f05e0d53739309bb2d093866b77ced9bc2000d2	\N	2026-01-01 00:00:00	current	2000-01-01 00:00:00+00	2000-01-01 00:00:00+00
\.


--
-- Data for Name: terms_version_content; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.terms_version_content (terms_version_id, content_text_en_us, content_text_es) FROM stdin;
a0000000-0000-4000-8000-000000000001	**Acceptance and eligibility**\nYou must accept the latest terms to continue. Accepting now keeps your account eligible to receive Metaboost messages.\n**Scope**\nThese terms apply to MetaBoost message and related metadata delivery. By using the service, you agree to the terms below.\n**Service purpose**\nMetaBoost is an external service that helps connect creator-facing messages to payment events. MetaBoost does not process, receive, or custody user payments.\n**Payment estimates**\nValues shown in MetaBoost are a best-effort estimate. We cannot guarantee accuracy, and you should confirm with your payment service provider what final payment amount you actually received.\n**Messages and payments**\nA message does not guarantee that a payment was sent, settled, or received. Payment flow is handled separately between the message sender and their payment service provider.\n**Refunds and disputes**\nIf payment is successful but a message is missing, delayed, or not associated correctly, MetaBoost does not issue refunds. Payment disputes must be handled between the message sender, the content creator, and the payment service provider.\n**Availability**\nMessage acceptance and retrieval are provided on a best-effort basis. Downtime, network issues, provider outages, or malformed payloads may affect delivery or display.	**Aceptación y elegibilidad**\nDebes aceptar los términos más recientes para continuar. Si aceptas ahora, tu cuenta sigue siendo apta para recibir mensajes de Metaboost.\n**Alcance**\nEstos términos se aplican a la entrega de mensajes de MetaBoost y metadatos relacionados. Al usar el servicio, aceptas los términos a continuación.\n**Propósito del servicio**\nMetaBoost es un servicio externo que ayuda a conectar mensajes para creadores con eventos de pago. MetaBoost no procesa, recibe ni custodia pagos de usuarios.\n**Estimaciones de pago**\nLos valores mostrados en MetaBoost son una estimación de mejor esfuerzo. No podemos garantizar la precisión y debes confirmar con tu proveedor de servicios de pago cuál fue el importe final que realmente recibiste.\n**Mensajes y pagos**\nUn mensaje no garantiza que un pago haya sido enviado, liquidado o recibido. El flujo de pago se maneja por separado entre la persona que envía el mensaje y su proveedor de servicios de pago.\n**Reembolsos y disputas**\nSi el pago se realiza correctamente pero falta un mensaje, se retrasa o no se asocia correctamente, MetaBoost no emite reembolsos. Las disputas de pago deben resolverse entre quien envía el mensaje, el creador de contenido y el proveedor de servicios de pago.\n**Disponibilidad**\nLa aceptación y recuperación de mensajes se ofrece sobre una base de mejor esfuerzo. Caídas, problemas de red, interrupciones del proveedor o cargas mal formadas pueden afectar la entrega o visualización.
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."user" (id, email_verified_at, id_text, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_bio; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_bio (user_id, display_name, preferred_currency) FROM stdin;
\.


--
-- Data for Name: user_credentials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_credentials (user_id, email, username, password_hash) FROM stdin;
\.


--
-- Data for Name: user_terms_acceptance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_terms_acceptance (id, user_id, terms_version_id, accepted_at, acceptance_source, created_at) FROM stdin;
\.


--
-- Data for Name: user_trust_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_trust_settings (user_id, membership_tier, membership_expires_at, auto_renew, created_at, updated_at, billing_cadence, auto_renew_mode, next_renewal_attempt_at, last_renewal_attempt_at, last_renewal_status, last_extension_idempotency_key, last_renewal_idempotency_key, renewal_retry_count, renewal_retry_backoff_until) FROM stdin;
\.


--
-- Data for Name: user_web_push_subscription; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_web_push_subscription (id, user_id, endpoint, key_p256dh, key_auth, locale, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: verification_token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.verification_token (id, user_id, kind, token_hash, expires_at, payload) FROM stdin;
\.


--
-- Name: billing_domain_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.billing_domain_event_id_seq', 1, false);


--
-- Name: billing_price_change_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.billing_price_change_audit_id_seq', 1, false);


--
-- Name: billing_price_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.billing_price_id_seq', 2, true);


--
-- Name: billing_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.billing_product_id_seq', 1, true);


--
-- Name: linear_migration_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.linear_migration_history_id_seq', 5, true);


--
-- Name: billing_domain_event billing_domain_event_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_domain_event
    ADD CONSTRAINT billing_domain_event_pkey PRIMARY KEY (id);


--
-- Name: billing_price_change_audit billing_price_change_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_price_change_audit
    ADD CONSTRAINT billing_price_change_audit_pkey PRIMARY KEY (id);


--
-- Name: billing_price billing_price_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_price
    ADD CONSTRAINT billing_price_pkey PRIMARY KEY (id);


--
-- Name: billing_price billing_price_unique_window_start; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_price
    ADD CONSTRAINT billing_price_unique_window_start UNIQUE (billing_product_id, currency_code, billing_cadence, effective_from);


--
-- Name: billing_product billing_product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_product
    ADD CONSTRAINT billing_product_pkey PRIMARY KEY (id);


--
-- Name: billing_product billing_product_product_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_product
    ADD CONSTRAINT billing_product_product_code_key UNIQUE (product_code);


--
-- Name: bucket_admin bucket_admin_bucket_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_admin
    ADD CONSTRAINT bucket_admin_bucket_id_user_id_key UNIQUE (bucket_id, user_id);


--
-- Name: bucket_admin_invitation bucket_admin_invitation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_admin_invitation
    ADD CONSTRAINT bucket_admin_invitation_pkey PRIMARY KEY (id);


--
-- Name: bucket_admin_invitation bucket_admin_invitation_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_admin_invitation
    ADD CONSTRAINT bucket_admin_invitation_token_key UNIQUE (token);


--
-- Name: bucket_admin bucket_admin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_admin
    ADD CONSTRAINT bucket_admin_pkey PRIMARY KEY (id);


--
-- Name: bucket_blocked_app bucket_blocked_app_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_blocked_app
    ADD CONSTRAINT bucket_blocked_app_pkey PRIMARY KEY (id);


--
-- Name: bucket_blocked_app bucket_blocked_app_root_bucket_id_app_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_blocked_app
    ADD CONSTRAINT bucket_blocked_app_root_bucket_id_app_id_key UNIQUE (root_bucket_id, app_id);


--
-- Name: bucket_blocked_sender bucket_blocked_sender_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_blocked_sender
    ADD CONSTRAINT bucket_blocked_sender_pkey PRIMARY KEY (id);


--
-- Name: bucket_blocked_sender bucket_blocked_sender_root_bucket_id_sender_guid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_blocked_sender
    ADD CONSTRAINT bucket_blocked_sender_root_bucket_id_sender_guid_key UNIQUE (root_bucket_id, sender_guid);


--
-- Name: bucket_message_app_meta bucket_message_app_meta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_message_app_meta
    ADD CONSTRAINT bucket_message_app_meta_pkey PRIMARY KEY (bucket_message_id);


--
-- Name: bucket_message bucket_message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_message
    ADD CONSTRAINT bucket_message_pkey PRIMARY KEY (id);


--
-- Name: bucket_message_value bucket_message_value_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_message_value
    ADD CONSTRAINT bucket_message_value_pkey PRIMARY KEY (bucket_message_id);


--
-- Name: bucket_notification_preference bucket_notification_preference_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_notification_preference
    ADD CONSTRAINT bucket_notification_preference_pkey PRIMARY KEY (id);


--
-- Name: bucket_notification_preference bucket_notification_preference_user_id_bucket_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_notification_preference
    ADD CONSTRAINT bucket_notification_preference_user_id_bucket_id_key UNIQUE (user_id, bucket_id);


--
-- Name: bucket bucket_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket
    ADD CONSTRAINT bucket_pkey PRIMARY KEY (id);


--
-- Name: bucket_role bucket_role_bucket_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_role
    ADD CONSTRAINT bucket_role_bucket_id_name_key UNIQUE (bucket_id, name);


--
-- Name: bucket_role bucket_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_role
    ADD CONSTRAINT bucket_role_pkey PRIMARY KEY (id);


--
-- Name: bucket_rss_channel_info bucket_rss_channel_info_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_rss_channel_info
    ADD CONSTRAINT bucket_rss_channel_info_pkey PRIMARY KEY (bucket_id);


--
-- Name: bucket_rss_channel_info bucket_rss_channel_info_rss_podcast_guid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_rss_channel_info
    ADD CONSTRAINT bucket_rss_channel_info_rss_podcast_guid_key UNIQUE (rss_podcast_guid);


--
-- Name: bucket_rss_item_info bucket_rss_item_info_parent_rss_channel_bucket_id_rss_item__key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_rss_item_info
    ADD CONSTRAINT bucket_rss_item_info_parent_rss_channel_bucket_id_rss_item__key UNIQUE (parent_rss_channel_bucket_id, rss_item_guid);


--
-- Name: bucket_rss_item_info bucket_rss_item_info_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_rss_item_info
    ADD CONSTRAINT bucket_rss_item_info_pkey PRIMARY KEY (bucket_id);


--
-- Name: bucket_settings bucket_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_settings
    ADD CONSTRAINT bucket_settings_pkey PRIMARY KEY (bucket_id);


--
-- Name: global_blocked_app global_blocked_app_app_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_blocked_app
    ADD CONSTRAINT global_blocked_app_app_id_key UNIQUE (app_id);


--
-- Name: global_blocked_app global_blocked_app_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_blocked_app
    ADD CONSTRAINT global_blocked_app_pkey PRIMARY KEY (id);


--
-- Name: linear_migration_history linear_migration_history_migration_filename_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.linear_migration_history
    ADD CONSTRAINT linear_migration_history_migration_filename_key UNIQUE (migration_filename);


--
-- Name: linear_migration_history linear_migration_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.linear_migration_history
    ADD CONSTRAINT linear_migration_history_pkey PRIMARY KEY (id);


--
-- Name: product_membership_settings product_membership_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_membership_settings
    ADD CONSTRAINT product_membership_settings_pkey PRIMARY KEY (id);


--
-- Name: refresh_token refresh_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_token
    ADD CONSTRAINT refresh_token_pkey PRIMARY KEY (id);


--
-- Name: terms_version_content terms_version_content_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terms_version_content
    ADD CONSTRAINT terms_version_content_pkey PRIMARY KEY (terms_version_id);


--
-- Name: terms_version terms_version_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terms_version
    ADD CONSTRAINT terms_version_pkey PRIMARY KEY (id);


--
-- Name: terms_version terms_version_version_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terms_version
    ADD CONSTRAINT terms_version_version_key_key UNIQUE (version_key);


--
-- Name: user_bio user_bio_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_bio
    ADD CONSTRAINT user_bio_pkey PRIMARY KEY (user_id);


--
-- Name: user_credentials user_credentials_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_email_key UNIQUE (email);


--
-- Name: user_credentials user_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_pkey PRIMARY KEY (user_id);


--
-- Name: user_credentials user_credentials_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_username_key UNIQUE (username);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: user_terms_acceptance user_terms_acceptance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_terms_acceptance
    ADD CONSTRAINT user_terms_acceptance_pkey PRIMARY KEY (id);


--
-- Name: user_terms_acceptance user_terms_acceptance_user_id_terms_version_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_terms_acceptance
    ADD CONSTRAINT user_terms_acceptance_user_id_terms_version_id_key UNIQUE (user_id, terms_version_id);


--
-- Name: user_trust_settings user_trust_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_trust_settings
    ADD CONSTRAINT user_trust_settings_pkey PRIMARY KEY (user_id);


--
-- Name: user_web_push_subscription user_web_push_subscription_endpoint_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_web_push_subscription
    ADD CONSTRAINT user_web_push_subscription_endpoint_key UNIQUE (endpoint);


--
-- Name: user_web_push_subscription user_web_push_subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_web_push_subscription
    ADD CONSTRAINT user_web_push_subscription_pkey PRIMARY KEY (id);


--
-- Name: verification_token verification_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_token
    ADD CONSTRAINT verification_token_pkey PRIMARY KEY (id);


--
-- Name: idx_billing_domain_event_type_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_domain_event_type_created ON public.billing_domain_event USING btree (event_type, created_at DESC);


--
-- Name: idx_billing_domain_event_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_domain_event_user_created ON public.billing_domain_event USING btree (user_id, created_at DESC);


--
-- Name: idx_billing_price_effective_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_price_effective_lookup ON public.billing_price USING btree (billing_product_id, billing_cadence, currency_code, effective_from DESC);


--
-- Name: idx_bucket_admin_bucket_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_admin_bucket_id ON public.bucket_admin USING btree (bucket_id);


--
-- Name: idx_bucket_admin_invitation_bucket_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_admin_invitation_bucket_id ON public.bucket_admin_invitation USING btree (bucket_id);


--
-- Name: idx_bucket_admin_invitation_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_admin_invitation_status ON public.bucket_admin_invitation USING btree (status);


--
-- Name: idx_bucket_admin_invitation_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_admin_invitation_token ON public.bucket_admin_invitation USING btree (token);


--
-- Name: idx_bucket_admin_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_admin_user_id ON public.bucket_admin USING btree (user_id);


--
-- Name: idx_bucket_blocked_app_app_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_blocked_app_app_id ON public.bucket_blocked_app USING btree (app_id);


--
-- Name: idx_bucket_blocked_app_root_bucket_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_blocked_app_root_bucket_id ON public.bucket_blocked_app USING btree (root_bucket_id);


--
-- Name: idx_bucket_blocked_sender_root_bucket_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_blocked_sender_root_bucket_id ON public.bucket_blocked_sender USING btree (root_bucket_id);


--
-- Name: idx_bucket_id_text; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_bucket_id_text ON public.bucket USING btree (id_text);


--
-- Name: idx_bucket_message_bucket_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_message_bucket_id ON public.bucket_message USING btree (bucket_id);


--
-- Name: idx_bucket_message_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_message_created_at ON public.bucket_message USING btree (created_at);


--
-- Name: idx_bucket_message_message_guid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_bucket_message_message_guid ON public.bucket_message USING btree (message_guid);


--
-- Name: idx_bucket_message_value_amount_unit; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_message_value_amount_unit ON public.bucket_message_value USING btree (amount_unit);


--
-- Name: idx_bucket_message_value_currency; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_message_value_currency ON public.bucket_message_value USING btree (currency);


--
-- Name: idx_bucket_message_value_threshold_amount_minor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_message_value_threshold_amount_minor ON public.bucket_message_value USING btree (threshold_amount_minor_at_create);


--
-- Name: idx_bucket_message_value_threshold_currency; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_message_value_threshold_currency ON public.bucket_message_value USING btree (threshold_currency_at_create);


--
-- Name: idx_bucket_notification_preference_bucket_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_notification_preference_bucket_id ON public.bucket_notification_preference USING btree (bucket_id);


--
-- Name: idx_bucket_notification_preference_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_notification_preference_user_id ON public.bucket_notification_preference USING btree (user_id);


--
-- Name: idx_bucket_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_owner_id ON public.bucket USING btree (owner_id);


--
-- Name: idx_bucket_parent_bucket_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_parent_bucket_id ON public.bucket USING btree (parent_bucket_id);


--
-- Name: idx_bucket_parent_bucket_id_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_parent_bucket_id_type ON public.bucket USING btree (parent_bucket_id, type);


--
-- Name: idx_bucket_role_bucket_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_role_bucket_id ON public.bucket_role USING btree (bucket_id);


--
-- Name: idx_bucket_rss_item_info_guid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_rss_item_info_guid ON public.bucket_rss_item_info USING btree (rss_item_guid);


--
-- Name: idx_bucket_rss_item_info_parent_channel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_rss_item_info_parent_channel ON public.bucket_rss_item_info USING btree (parent_rss_channel_bucket_id);


--
-- Name: idx_bucket_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bucket_type ON public.bucket USING btree (type);


--
-- Name: idx_global_blocked_app_app_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_global_blocked_app_app_id ON public.global_blocked_app USING btree (app_id);


--
-- Name: idx_linear_migration_history_applied_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_linear_migration_history_applied_at ON public.linear_migration_history USING btree (applied_at DESC);


--
-- Name: idx_refresh_token_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refresh_token_expires_at ON public.refresh_token USING btree (expires_at);


--
-- Name: idx_refresh_token_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_refresh_token_hash ON public.refresh_token USING btree (token_hash);


--
-- Name: idx_refresh_token_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refresh_token_user_id ON public.refresh_token USING btree (user_id);


--
-- Name: idx_terms_version_single_current; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_terms_version_single_current ON public.terms_version USING btree (status) WHERE ((status)::text = 'current'::text);


--
-- Name: idx_terms_version_single_upcoming; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_terms_version_single_upcoming ON public.terms_version USING btree (status) WHERE ((status)::text = 'upcoming'::text);


--
-- Name: idx_terms_version_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_terms_version_status ON public.terms_version USING btree (status);


--
-- Name: idx_user_id_text; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_user_id_text ON public."user" USING btree (id_text);


--
-- Name: idx_user_terms_acceptance_terms_version_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_terms_acceptance_terms_version_id ON public.user_terms_acceptance USING btree (terms_version_id);


--
-- Name: idx_user_terms_acceptance_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_terms_acceptance_user_id ON public.user_terms_acceptance USING btree (user_id);


--
-- Name: idx_user_trust_settings_next_renewal_attempt_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_trust_settings_next_renewal_attempt_at ON public.user_trust_settings USING btree (next_renewal_attempt_at) WHERE (next_renewal_attempt_at IS NOT NULL);


--
-- Name: idx_user_trust_settings_renewal_retry_backoff_until; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_trust_settings_renewal_retry_backoff_until ON public.user_trust_settings USING btree (renewal_retry_backoff_until) WHERE (renewal_retry_backoff_until IS NOT NULL);


--
-- Name: idx_user_web_push_subscription_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_web_push_subscription_user_id ON public.user_web_push_subscription USING btree (user_id);


--
-- Name: idx_verification_token_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_verification_token_expires_at ON public.verification_token USING btree (expires_at);


--
-- Name: idx_verification_token_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_verification_token_hash ON public.verification_token USING btree (token_hash);


--
-- Name: uq_billing_domain_event_idempotency_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_billing_domain_event_idempotency_key ON public.billing_domain_event USING btree (idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: uq_billing_price_open_window; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_billing_price_open_window ON public.billing_price USING btree (billing_product_id, currency_code, billing_cadence) WHERE (effective_to IS NULL);


--
-- Name: billing_price set_updated_at_billing_price; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_updated_at_billing_price BEFORE UPDATE ON public.billing_price FOR EACH ROW EXECUTE FUNCTION public.set_updated_at_field();


--
-- Name: billing_product set_updated_at_billing_product; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_updated_at_billing_product BEFORE UPDATE ON public.billing_product FOR EACH ROW EXECUTE FUNCTION public.set_updated_at_field();


--
-- Name: bucket set_updated_at_bucket; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_updated_at_bucket BEFORE UPDATE ON public.bucket FOR EACH ROW EXECUTE FUNCTION public.set_updated_at_field();


--
-- Name: bucket_notification_preference set_updated_at_bucket_notification_preference; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_updated_at_bucket_notification_preference BEFORE UPDATE ON public.bucket_notification_preference FOR EACH ROW EXECUTE FUNCTION public.set_updated_at_field();


--
-- Name: product_membership_settings set_updated_at_product_membership_settings; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_updated_at_product_membership_settings BEFORE UPDATE ON public.product_membership_settings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at_field();


--
-- Name: terms_version set_updated_at_terms_version; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_updated_at_terms_version BEFORE UPDATE ON public.terms_version FOR EACH ROW EXECUTE FUNCTION public.set_updated_at_field();


--
-- Name: user set_updated_at_user; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_updated_at_user BEFORE UPDATE ON public."user" FOR EACH ROW EXECUTE FUNCTION public.set_updated_at_field();


--
-- Name: user_trust_settings set_updated_at_user_trust_settings; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_updated_at_user_trust_settings BEFORE UPDATE ON public.user_trust_settings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at_field();


--
-- Name: user_web_push_subscription set_updated_at_user_web_push_subscription; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER set_updated_at_user_web_push_subscription BEFORE UPDATE ON public.user_web_push_subscription FOR EACH ROW EXECUTE FUNCTION public.set_updated_at_field();


--
-- Name: billing_domain_event billing_domain_event_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_domain_event
    ADD CONSTRAINT billing_domain_event_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: billing_price billing_price_billing_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_price
    ADD CONSTRAINT billing_price_billing_product_id_fkey FOREIGN KEY (billing_product_id) REFERENCES public.billing_product(id) ON DELETE CASCADE;


--
-- Name: billing_price_change_audit billing_price_change_audit_billing_price_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_price_change_audit
    ADD CONSTRAINT billing_price_change_audit_billing_price_id_fkey FOREIGN KEY (billing_price_id) REFERENCES public.billing_price(id) ON DELETE SET NULL;


--
-- Name: bucket_admin bucket_admin_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_admin
    ADD CONSTRAINT bucket_admin_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: bucket_admin_invitation bucket_admin_invitation_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_admin_invitation
    ADD CONSTRAINT bucket_admin_invitation_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: bucket_admin bucket_admin_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_admin
    ADD CONSTRAINT bucket_admin_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: bucket_blocked_app bucket_blocked_app_root_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_blocked_app
    ADD CONSTRAINT bucket_blocked_app_root_bucket_id_fkey FOREIGN KEY (root_bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: bucket_blocked_sender bucket_blocked_sender_root_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_blocked_sender
    ADD CONSTRAINT bucket_blocked_sender_root_bucket_id_fkey FOREIGN KEY (root_bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: bucket_message_app_meta bucket_message_app_meta_bucket_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_message_app_meta
    ADD CONSTRAINT bucket_message_app_meta_bucket_message_id_fkey FOREIGN KEY (bucket_message_id) REFERENCES public.bucket_message(id) ON DELETE CASCADE;


--
-- Name: bucket_message bucket_message_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_message
    ADD CONSTRAINT bucket_message_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: bucket_message_value bucket_message_value_bucket_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_message_value
    ADD CONSTRAINT bucket_message_value_bucket_message_id_fkey FOREIGN KEY (bucket_message_id) REFERENCES public.bucket_message(id) ON DELETE CASCADE;


--
-- Name: bucket_notification_preference bucket_notification_preference_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_notification_preference
    ADD CONSTRAINT bucket_notification_preference_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: bucket_notification_preference bucket_notification_preference_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_notification_preference
    ADD CONSTRAINT bucket_notification_preference_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: bucket bucket_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket
    ADD CONSTRAINT bucket_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: bucket bucket_parent_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket
    ADD CONSTRAINT bucket_parent_bucket_id_fkey FOREIGN KEY (parent_bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: bucket_role bucket_role_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_role
    ADD CONSTRAINT bucket_role_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: bucket_rss_channel_info bucket_rss_channel_info_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_rss_channel_info
    ADD CONSTRAINT bucket_rss_channel_info_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: bucket_rss_item_info bucket_rss_item_info_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_rss_item_info
    ADD CONSTRAINT bucket_rss_item_info_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: bucket_rss_item_info bucket_rss_item_info_parent_rss_channel_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_rss_item_info
    ADD CONSTRAINT bucket_rss_item_info_parent_rss_channel_bucket_id_fkey FOREIGN KEY (parent_rss_channel_bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: bucket_settings bucket_settings_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bucket_settings
    ADD CONSTRAINT bucket_settings_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: refresh_token refresh_token_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_token
    ADD CONSTRAINT refresh_token_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: terms_version_content terms_version_content_terms_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.terms_version_content
    ADD CONSTRAINT terms_version_content_terms_version_id_fkey FOREIGN KEY (terms_version_id) REFERENCES public.terms_version(id) ON DELETE CASCADE;


--
-- Name: user_bio user_bio_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_bio
    ADD CONSTRAINT user_bio_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: user_credentials user_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_credentials
    ADD CONSTRAINT user_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: user_terms_acceptance user_terms_acceptance_terms_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_terms_acceptance
    ADD CONSTRAINT user_terms_acceptance_terms_version_id_fkey FOREIGN KEY (terms_version_id) REFERENCES public.terms_version(id) ON DELETE CASCADE;


--
-- Name: user_terms_acceptance user_terms_acceptance_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_terms_acceptance
    ADD CONSTRAINT user_terms_acceptance_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: user_trust_settings user_trust_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_trust_settings
    ADD CONSTRAINT user_trust_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: user_web_push_subscription user_web_push_subscription_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_web_push_subscription
    ADD CONSTRAINT user_web_push_subscription_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: verification_token verification_token_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.verification_token
    ADD CONSTRAINT verification_token_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA public TO metaboost_app_migrator;


--
-- Name: TABLE billing_domain_event; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.billing_domain_event TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.billing_domain_event TO metaboost_app_read;


--
-- Name: SEQUENCE billing_domain_event_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.billing_domain_event_id_seq TO metaboost_app_read_write;
GRANT SELECT ON SEQUENCE public.billing_domain_event_id_seq TO metaboost_app_read;


--
-- Name: TABLE billing_price; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.billing_price TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.billing_price TO metaboost_app_read;


--
-- Name: TABLE billing_price_change_audit; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.billing_price_change_audit TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.billing_price_change_audit TO metaboost_app_read;


--
-- Name: SEQUENCE billing_price_change_audit_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.billing_price_change_audit_id_seq TO metaboost_app_read_write;
GRANT SELECT ON SEQUENCE public.billing_price_change_audit_id_seq TO metaboost_app_read;


--
-- Name: SEQUENCE billing_price_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.billing_price_id_seq TO metaboost_app_read_write;
GRANT SELECT ON SEQUENCE public.billing_price_id_seq TO metaboost_app_read;


--
-- Name: TABLE billing_product; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.billing_product TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.billing_product TO metaboost_app_read;


--
-- Name: SEQUENCE billing_product_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.billing_product_id_seq TO metaboost_app_read_write;
GRANT SELECT ON SEQUENCE public.billing_product_id_seq TO metaboost_app_read;


--
-- Name: TABLE bucket; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.bucket TO metaboost_app_read;


--
-- Name: TABLE bucket_admin; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_admin TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.bucket_admin TO metaboost_app_read;


--
-- Name: TABLE bucket_admin_invitation; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_admin_invitation TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.bucket_admin_invitation TO metaboost_app_read;


--
-- Name: TABLE bucket_blocked_app; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_blocked_app TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.bucket_blocked_app TO metaboost_app_read;


--
-- Name: TABLE bucket_blocked_sender; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_blocked_sender TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.bucket_blocked_sender TO metaboost_app_read;


--
-- Name: TABLE bucket_message; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_message TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.bucket_message TO metaboost_app_read;


--
-- Name: TABLE bucket_message_app_meta; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_message_app_meta TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.bucket_message_app_meta TO metaboost_app_read;


--
-- Name: TABLE bucket_message_value; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_message_value TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.bucket_message_value TO metaboost_app_read;


--
-- Name: TABLE bucket_notification_preference; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_notification_preference TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.bucket_notification_preference TO metaboost_app_read;


--
-- Name: TABLE bucket_role; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_role TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.bucket_role TO metaboost_app_read;


--
-- Name: TABLE bucket_rss_channel_info; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_rss_channel_info TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.bucket_rss_channel_info TO metaboost_app_read;


--
-- Name: TABLE bucket_rss_item_info; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_rss_item_info TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.bucket_rss_item_info TO metaboost_app_read;


--
-- Name: TABLE bucket_settings; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.bucket_settings TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.bucket_settings TO metaboost_app_read;


--
-- Name: TABLE global_blocked_app; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.global_blocked_app TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.global_blocked_app TO metaboost_app_read;


--
-- Name: TABLE linear_migration_history; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.linear_migration_history TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.linear_migration_history TO metaboost_app_read;


--
-- Name: SEQUENCE linear_migration_history_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON SEQUENCE public.linear_migration_history_id_seq TO metaboost_app_read_write;
GRANT SELECT ON SEQUENCE public.linear_migration_history_id_seq TO metaboost_app_read;


--
-- Name: TABLE product_membership_settings; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.product_membership_settings TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.product_membership_settings TO metaboost_app_read;


--
-- Name: TABLE refresh_token; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.refresh_token TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.refresh_token TO metaboost_app_read;


--
-- Name: TABLE terms_version; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.terms_version TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.terms_version TO metaboost_app_read;


--
-- Name: TABLE terms_version_content; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.terms_version_content TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.terms_version_content TO metaboost_app_read;


--
-- Name: TABLE "user"; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public."user" TO metaboost_app_read_write;
GRANT SELECT ON TABLE public."user" TO metaboost_app_read;


--
-- Name: TABLE user_bio; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.user_bio TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.user_bio TO metaboost_app_read;


--
-- Name: TABLE user_credentials; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.user_credentials TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.user_credentials TO metaboost_app_read;


--
-- Name: TABLE user_terms_acceptance; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.user_terms_acceptance TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.user_terms_acceptance TO metaboost_app_read;


--
-- Name: TABLE user_trust_settings; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.user_trust_settings TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.user_trust_settings TO metaboost_app_read;


--
-- Name: TABLE user_web_push_subscription; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.user_web_push_subscription TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.user_web_push_subscription TO metaboost_app_read;


--
-- Name: TABLE verification_token; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.verification_token TO metaboost_app_read_write;
GRANT SELECT ON TABLE public.verification_token TO metaboost_app_read;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE metaboost_app_migrator IN SCHEMA public GRANT ALL ON SEQUENCES TO metaboost_app_read_write;
ALTER DEFAULT PRIVILEGES FOR ROLE metaboost_app_migrator IN SCHEMA public GRANT SELECT ON SEQUENCES TO metaboost_app_read;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE metaboost_app_migrator IN SCHEMA public GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLES TO metaboost_app_read_write;
ALTER DEFAULT PRIVILEGES FOR ROLE metaboost_app_migrator IN SCHEMA public GRANT SELECT ON TABLES TO metaboost_app_read;


--
-- PostgreSQL database dump complete
--




-- App database linear migration history
INSERT INTO public.linear_migration_history (migration_filename, migration_checksum) VALUES
  ('0001_app_schema.sql', '4de5eeec8349173fc44fa42b1a5c2d79531961b192b7e44814eb92033e46c528'),
  ('0002_terms_default_seed.sql', '80f813bba7561e0851b98a8e2ecf079ec465ea3b6265142992842f6b9ec953cc'),
  ('0003_user_trust_and_entitlement_overrides.sql', '0fd77e59786273ff61914bf122475ad244a15c26102836f82dcba662f8aa6cab'),
  ('0004_billing_catalog_and_trust_renewal.sql', '0b24fc8f7e04153c62055374892e3eb1fac81872717b17534703c65f930c45bf'),
  ('0005_billing_domain_events.sql', '3e8d4ce2c3b109bc08bfa66c8b9b5de33325d40e7ec6a17cdaac47648ccd7dbc')
ON CONFLICT (migration_filename) DO NOTHING;
